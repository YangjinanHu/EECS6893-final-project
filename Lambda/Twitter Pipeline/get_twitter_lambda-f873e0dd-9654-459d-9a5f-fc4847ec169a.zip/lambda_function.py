import base64
import requests
import json
import boto3
import time
import datetime
import os
import re
import re
import math
import numpy as np

def get_company_tweet(company_name):
    # Define your keys from the twitter developer portal
    client_key = ''
    client_secret = ''

    # Reformat the keys and encode them

    # we start in unicode and then transform to bytes
    key_secret = '{}:{}'.format(client_key, client_secret).encode('ascii')

    # Transform from bytes to bytes that can be printed
    b64_encoded_key = base64.b64encode(key_secret)

    # Transform from bytes back into Unicode
    b64_encoded_key = b64_encoded_key.decode('ascii')

    base_url = 'https://api.twitter.com/'
    auth_url = '{}oauth2/token'.format(base_url)

    auth_headers = {
        'Authorization': 'Basic {}'.format(b64_encoded_key),
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
    }

    auth_data = {
        'grant_type': 'client_credentials'
    }

    auth_resp = requests.post(auth_url, headers=auth_headers, data=auth_data)

    access_token = auth_resp.json()['access_token']

    search_headers = {
        'Authorization': 'Bearer {}'.format(access_token)
    }

    search_params = {
        'q': company_name,  # + since + until,
        'result_type': 'recent',
        'tweet_mode': 'extended',
        'count': 1000
    }

    search_url = '{}1.1/search/tweets.json'.format(base_url)

    search_resp = requests.get(search_url, headers=search_headers, params=search_params)

    now = datetime.datetime.now()
    format_now = datetime.datetime.strftime(now, '%Y-%m-%d %H:%M:%S')

    Data = json.loads(search_resp.content)
    records = list(
        map((lambda x: {"Data": json.dumps({'datetime': format_now, 'source': 'twitter', 'text': x.get('full_text'),
                                            'location': x.get('user').get('location'),
                                            'user': x.get('user').get('screen_name')}, ensure_ascii=False)}),
            Data.get('statuses')))

    print('{} new records. '.format(len(records)))
    if len(records) <= 0:
        print(search_params)

    res = []
    for sentence in records:
        sentence = json.loads(sentence['Data'])['text']
        sentence = re.sub("[^a-zA-Z0-9]+", " ", sentence)
        sentence = ' '.join(sentence.strip().split('\n'))
        if sentence and len(sentence.strip().split()) >= 5:
            res.append(sentence.strip())
    return res

def _load_word_index(path):
    word_index = {}
    with open(path, encoding='utf-8') as f:
        content = f.readlines()
    for line in content:
        word, index = line.strip().split('\t')
        word_index[word] = index
    return word_index

def _load_data(data, max_seq_len, word_index):
    index_x = []
    for line in data:
        txt = re.sub("^\s*(.-)\s*$", "%1", line).replace('\n', '').replace('@', '').replace('#', '').split()
        txt_len = len(txt)
        x = np.zeros(max_seq_len, dtype=np.int32)
        if txt_len <= max_seq_len:
            for i in range(txt_len):
                try:
                    x[i] = word_index[txt[i]]
                except:
                    x[i] = 2
        else:
            for i in range(max_seq_len):
                try:
                    x[i] = word_index[txt[i]]
                except:
                    x[i] = 2
        index_x.append(x)
    index_data = np.array(index_x)
    return index_data


def parse_tweet(raw_data,company_name):
#     print(raw_data)
    word_index_tc_path = 'topic_cls_dict.txt'
    word_index_fn_path = 'fake_news_dict.txt'
    word_index_tc = _load_word_index(word_index_tc_path)
    word_index_fn = _load_word_index(word_index_fn_path)
    input_index_data = _load_data(raw_data, 128, word_index_tc)
    
    runtime = boto3.Session().client(service_name='sagemaker-runtime', region_name='us-east-2')
    ENDPOINT_1 = ''  # cls
    ENDPOINT_2 = ''  # filter

    steps = math.ceil(len(input_index_data) / 32)
    preds_tc = []
    for i in range(steps):
        input_x = input_index_data[i * 32:(i + 1) * 32]
        payload = ','.join(str(x) for x in input_x.tolist())
        payload = payload.replace("],[","\n").replace("[","").replace("]","")
        raw_prob = runtime.invoke_endpoint(EndpointName=ENDPOINT_1, ContentType='text/csv', Body=payload)
        raw_prob = json.loads(raw_prob['Body'].read().decode("utf-8"))['predictions']
        label = np.argmax(np.asarray(raw_prob),axis=1)
        preds_tc.extend(label)

    data_after_tc=[]
    for idx, label in enumerate(preds_tc):
        if label==1 or label==2:
            data_after_tc.append(raw_data[idx])
    input_index_data=_load_data(data_after_tc, 256, word_index_fn)
    steps=math.ceil(len(input_index_data)/32)
    preds_fn=[]
    for i in range(steps):
        input_x=input_index_data[i*32:(i+1)*32]
        payload = ','.join(str(x) for x in input_x.tolist())
        payload = payload.replace("],[","\n").replace("[","").replace("]","")
        raw_prob = runtime.invoke_endpoint(EndpointName=ENDPOINT_2, ContentType='text/csv', Body=payload)
        raw_prob = json.loads(raw_prob['Body'].read().decode("utf-8"))['predictions']
        label = np.argmax(np.asarray(raw_prob),axis=1)
        preds_fn.extend(label)
    result=[]
    for idx, label in enumerate(preds_fn):
        if label==0:
            result.append(data_after_tc[idx])
#     print(data_after_tc)
    result = [{'Data': json.dumps({'Data': i + "\n", 'company_name': company_name}).encode('utf-8')} for i in result]
    return result
    
def lambda_handler(event, context):
    
    company_name = ['Apple','Tesla','Google','Meta','Amazon','Netflix','Microsoft','Uber','Tencent','Alibaba','Twitter']
    
    for c in company_name:
        raw = get_company_tweet(c)
    
        result = parse_tweet(raw,c)   
    
        client = boto3.client("firehose", region_name="us-east-1")
        client.put_record_batch(
                    DeliveryStreamName="twitter_stream_v2",
                    Records=result,
                )
            
    return {
        'statusCode': 200,
        'body': json.dumps('Done')
    }